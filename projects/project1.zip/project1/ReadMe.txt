Copy the folder 'p1' to the 'src' folder inside your IntelliJ COP 3530 project. Just copy/paste.
So, 'p1' will now appear as a package ( a folder) inside your IntelliJ COP 3530 project under 'src'.
'p1' is the package name; you must not change it.