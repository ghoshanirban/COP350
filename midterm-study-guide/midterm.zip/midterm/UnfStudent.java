package midterm; // do not delete

public class UnfStudent {
    private Integer nNumber;
    private String name;
    private Double gpa;
	
	public UnfStudent(Integer nNumber, String name, Double gpa){
		this.nNumber = nNumber;
		this.name = name;
		this.gpa = gpa;
	}
	
	public Integer getnNumber() { return nNumber; }
	public String getName() { return name; }
	public Double getGPA() { return gpa; }


	public String toString() {
		return "<" + nNumber.toString() + ", " + name + ", " + gpa + "> ";
	}
}
