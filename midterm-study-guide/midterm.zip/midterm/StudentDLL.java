package midterm;

public class StudentDLL { // do not change the class name

	//---------------------Do not touch--------------------------------//
	private static class Node {
	    private UnfStudent studentInfo;
		private Node prev, next;

		public Node(Integer nNumber, String name, Double gpa) { studentInfo = new UnfStudent(nNumber, name, gpa); }
		public String toString() { return studentInfo.toString(); }
	}

	private Node head = null, tail = null; // Be careful, initially the head contains null
	public StudentDLL() { } // an empty constructor; nothing is to be done over here
	//---------------------Do not touch--------------------------------//


	// inserts a new new node at the end
	public void insertLast(Integer nNumber, String name, Double gpa) {

	}

	// inserts a new node at the beginning
	public void insertFirst(Integer nNumber, String name, Double gpa) {

	}

	// reverses the list and updates it head and tail
	public void reverse() {

	}

	public void sortBasedOnGpa(){
		// A O(n^2) time implementation would suffice
	}

	// returns the student record stored at kth position; k starts at 0
	public UnfStudent getkth(int k) {

		return head.studentInfo;
	}


	// inserts a new node at position 'pos'; pos starts at 0
	public void insertAt(int pos, Integer nNumber, String name, Double gpa){

	}

	// traverses the list from right to left and returns a string representation of the list
	public String traverseRight2Left(){
		return "";
	}


	// remove the node in which the stored N# is nNumber
	public void removeStudentHavingNNumber(Integer nNumber) {

	}

	// returns the number of nodes stored in the list
	public int size() {
		return 0;
	}

	// returns a string representation of the list
	public String toString() {

		return "";
	}
}
